define(["ScrollMagic", "ScrollMagic/debug.addIndicators"], function (ScrollMagic) {
	describe("", function() {
		xit("has method 'setTween'", function () {
			
		});
	});
});