define(["ScrollMagic", "ScrollMagic/animation.velocity"], function (ScrollMagic) {
	describe("", function() {
		xit("has method 'setTween'", function () {
			
		});
	});
});